function dx = differential_drive(x,u)
    
    % Velocity
    v = u(1);
    w = u(2);
    theta = x(3);
    
    % State update
    f_x = v * cos(theta);
    f_y = v * sin(theta);
    f_theta = w;

    dx = [f_x; f_y; f_theta];
end

